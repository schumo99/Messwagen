﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;


namespace ComPort
{
    public partial class Form1 : Form
    {
        string dataOUT;
        string dataIN;
        string CbusIN;
        double zahl_zurueck;

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            cBoxCOMPORT.Items.AddRange(ports);

            btnOpen.Enabled = true;
            btnClose.Enabled = false;
            chart1.Series[0].IsVisibleInLegend = false;
            chart1.Series.Add("Supercapspannung");
            chart1.Series.Add("Gleisspannung");
            chart1.Series.Add("Steigung");
            chart1.Series.Add("Neigung");
            chart1.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart1.Series[2].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart1.Series[3].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart1.Series[4].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.PortName = cBoxCOMPORT.Text;
                serialPort1.BaudRate = 57600;
                serialPort1.DataBits = 8;
                serialPort1.StopBits = (StopBits)Enum.Parse(typeof(StopBits), "One"); 
                serialPort1.Parity = (Parity)Enum.Parse(typeof(Parity), "None");
                /*
                serialPort1.BaudRate = Convert.ToInt32(CBoxBaudRate.Text);
                serialPort1.DataBits = Convert.ToInt32(cBoxDataBits.Text);
                serialPort1.StopBits = (StopBits)Enum.Parse(typeof(StopBits), cBoxStopBits.Text);
                serialPort1.Parity = (Parity)Enum.Parse(typeof(Parity), cBoxParityBits.Text);
                */
                serialPort1.Open();
                btnOpen.Enabled = false;
                btnClose.Enabled = true;
                lblStatusCom.Text = "ON";

            }

            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnOpen.Enabled = true;
                btnClose.Enabled = false;
                lblStatusCom.Text = "OFF";
            }


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
                btnOpen.Enabled = true;
                btnClose.Enabled = false;
                lblStatusCom.Text = "OFF";
            }
        }



        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            dataIN = serialPort1.ReadExisting();
            CbusIN += dataIN;
            this.Invoke(new EventHandler(ShowData));
        }

        private void ShowData(object sender, EventArgs e)
        {
            int CbusINLength = CbusIN.Length;
          //  tBoxDataIN.Text += dataIN;


            int kommandobeginn = -1;
            kommandobeginn = CbusIN.IndexOf('#');
            while (kommandobeginn > -1) {
                CbusIN = CbusIN.Substring(kommandobeginn);
              /*
                int endDaten;
                endDaten = CbusIN.IndexOf('\n');
                if (endDaten > -1)
                {
                    String CBUS_Daten;
                    CBUS_Daten = CbusIN.Substring(0, endDaten);
                    CbusIN = CbusIN.Substring(endDaten);
                    textBox1.Text = CBUS_Daten;
                    //handle_CBUS(CBUS_Daten, length);
                }
                */
                int startDaten;
                startDaten = 0;
                //startDaten = CbusIN.IndexOf('0');
                int endDaten;
                endDaten = CbusIN.IndexOf('\n');
                if (startDaten > -1 && (endDaten > startDaten))
                {
                    startDaten++;
                    int length;
                    length = endDaten - startDaten;
                    String CBUS_Daten;
                    CBUS_Daten = CbusIN.Substring(startDaten, length);
                    CbusIN = CbusIN.Substring(endDaten);
                    textBox1.Text = CBUS_Daten;
                    handle_CBUS(CBUS_Daten, length);
                }
 
                kommandobeginn = CbusIN.IndexOf('#');
                endDaten = CbusIN.IndexOf('\n');
                if (endDaten == -1)
                {
                    kommandobeginn = -1;
                    //MessageBox.Show(CbusIN);
                }
            }
        }


/*
        private void btnAbfragen_Click(object sender, EventArgs e)
        {
            try
            {
                int ii = lViewCBUS_Abfrage.Items.Count;
                for (int i = 0; i < ii; i++)
                {
                    lViewCBUS_Abfrage.Items[0].Remove();
                }
                if (serialPort1.IsOpen)
                {
                    dataOUT = ":X0C011000N;";
                    serialPort1.WriteLine(dataOUT);
                    dataOUT = ":X0C011300N;";
                    serialPort1.WriteLine(dataOUT);
                    dataOUT = ":SC020N0D;";
                    serialPort1.WriteLine(dataOUT);
                }
            }

            catch (Exception err)
            {
                MessageBox.Show(err.Message, "ErrorbtnAbfragen", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
*/

        private void handle_CBUS(String CBUS_Daten, int length)
        {

            int rpsstart = CBUS_Daten.IndexOf("rps:");
            int ZMarkstart = CBUS_Daten.IndexOf("ZMark:");
            int U0start = CBUS_Daten.IndexOf("U0:");
            int U1start = CBUS_Daten.IndexOf("U1:");
            int U6start = CBUS_Daten.IndexOf("U6:");
            int Steigstart = CBUS_Daten.IndexOf("Steig:");
            int Neigstart = CBUS_Daten.IndexOf("Neig:");
            int Speedstart = CBUS_Daten.IndexOf("Speed_");
            int VCntstart = CBUS_Daten.IndexOf("VCnt_");
            int VTimestart = CBUS_Daten.IndexOf("VTime_");
            int TVCntstart = CBUS_Daten.IndexOf("TVCnt_");
            int TVTimestart = CBUS_Daten.IndexOf("TVTime_");
            int TCntstart = CBUS_Daten.IndexOf("T_Cnt_");
            int TTimestart = CBUS_Daten.IndexOf("T_Time_");
            int stopleer=0;
            for (int i= length-1; i> TTimestart; i--)
            {
                if (CBUS_Daten.Substring(i, 1).IndexOf(' ') == 0)
                {
                    stopleer = i+1;
                    i = 0;
                }
            }
            String rpsData="";
            String ZMarkData="";
            String U0Data="";
            String U1Data="";
            String U6Data="";
            String Steig="";
            String Neig="";
            String Speed="";
            String VCnt="";
            String VTime="";
            String TVCnt="";
            String TVTime="";
            String TCnt="";
            String TTime="";
            if (ZMarkstart> rpsstart) rpsData = CBUS_Daten.Substring(rpsstart+4, ZMarkstart-1-(rpsstart + 4));
            if (U0start >ZMarkstart) ZMarkData = CBUS_Daten.Substring(ZMarkstart + 6, U0start-1-(ZMarkstart + 6));
            if (U1start > U0start) U0Data = CBUS_Daten.Substring(U0start + 3, U1start - 1-(U0start + 3));
            if (U6start > U1start) U1Data = CBUS_Daten.Substring(U1start + 3, U6start - 1-(U1start + 3));
            if (Steigstart>U6start) U6Data = CBUS_Daten.Substring(U6start + 3, Steigstart - 1-(U6start + 3));
            if (Neigstart>Steigstart) Steig = CBUS_Daten.Substring(Steigstart + 6, Neigstart - 1 - (Steigstart + 6));
            if (Speedstart > Neigstart) Neig = CBUS_Daten.Substring(Neigstart + 6, Speedstart - 1 - (Neigstart + 5));
            if (VCntstart >Speedstart) Speed = CBUS_Daten.Substring(Speedstart + 6, VCntstart - 1 - (Speedstart + 6));
            if (VTimestart>VCntstart) VCnt = CBUS_Daten.Substring(VCntstart + 5, VTimestart - 1 - (VCntstart + 5));
            if (TVCntstart>VTimestart) VTime = CBUS_Daten.Substring(VTimestart + 6, TVCntstart - 1 - (VTimestart + 6));
            if (TVTimestart>TVCntstart) TVCnt = CBUS_Daten.Substring(TVCntstart + 6, TVTimestart - 1 - (TVCntstart + 6));
            if (TCntstart> TVTimestart) TVTime = CBUS_Daten.Substring(TVTimestart + 7, TCntstart - 1 - (TVTimestart + 7));
            if (TTimestart > TCntstart) TCnt = CBUS_Daten.Substring(TCntstart + 6, TTimestart - 1 - (TCntstart + 6));
            if (stopleer - 1 - (TTimestart + 7)>0) TTime = CBUS_Daten.Substring(TTimestart + 7, stopleer - 1 - (TTimestart + 7));
            listView1.Items.Add(new ListViewItem(new string[] { rpsData, ZMarkData, U0Data, U1Data, U6Data, Steig, Neig, Speed, VCnt, VTime, TVCnt, TVTime, TCnt, TTime }));
            string_toInt(U0Data);
            chart1.Series["Gleisspannung"].Points.Add(zahl_zurueck);
            string_toInt(U6Data);
            chart1.Series["Supercapspannung"].Points.Add(zahl_zurueck);
            string_toInt(Steig);
            chart1.Series["Steigung"].Points.Add(zahl_zurueck);
            string_toInt(Neig);
            chart1.Series["Neigung"].Points.Add(zahl_zurueck);
        }

        public void string_toInt(string str)
        {
            String numericString = "";
            foreach (char c in str)
            {
                // Check for numeric characters (0-9), a negative sign, or leading or trailing spaces.
                if ((c >= '0' && c <= '9') || c == '-' || c == ',')
                {
                    numericString = string.Concat(numericString, c);
                }
                else if (c == '.')
                {
                    numericString = string.Concat(numericString, ",");
                }
            }
            zahl_zurueck = Convert.ToDouble(numericString);    
        }

        private void cBoxStopBits_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        /*
                private void neueModule_in_ListView(int[] cData)
                {          
                    try
                    {
                        listView1.Items.Add(new ListViewItem(new string[] { cData[1].ToString(), cData[2].ToString(),cData[3].ToString() }));
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show(err.Message, "ErrorListView", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                */
        /*
                private void lViewCBUS_Abfrage_SelectedIndexChanged(object sender, EventArgs e)
                {
                    int CAN_IDalt = selCANID;
                    ListView.SelectedListViewItemCollection CanAbfage = this.lViewCBUS_Abfrage.SelectedItems;
                    foreach (ListViewItem item in CanAbfage)
                    {
                        selCANID = Int16.Parse(item.SubItems[0].Text);
                    }
                    this.Text = "CAN - BUS Konfigurator  (CAN-ID:" + selCANID.ToString() + ")";
                    if (selCANID != CAN_IDalt)
                    {
                        int ii = listView1.Items.Count;
                        for (int i = 0; i < ii; i++)
                        {
                            listView1.Items[0].Remove();
                        }
                    }
                }


                      //  selCANID = Int16.Parse(item.SubItems[0].Text);
                      //  selTypID = Int16.Parse(item.SubItems[3].Text);


                private void VarAbrufen(int var)
                {
                    if (var == -1) return;
                    if (serialPort1.IsOpen)
                    {
                        dataOUT = String.Format(":SC020N71{0:X4}{1:X2};", selCANID, var);
                        //tBoxDataOut.Text += dataOUT;
                        //tBoxDataOut.Text += System.Environment.NewLine;
                        serialPort1.WriteLine(dataOUT);
                        Application.DoEvents();
                    }
                }



                private void warten(int zeit)
                {
                    Int64 ms;
                    ms = DateTime.Now.Ticks;
                    while ((DateTime.Now.Ticks - ms)<(zeit*10000))
                    {
                        Application.DoEvents();
                    }
                }
        */
    }

}
